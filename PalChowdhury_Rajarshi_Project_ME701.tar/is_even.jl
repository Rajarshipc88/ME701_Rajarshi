function is_even(n)
if n%2==0
return true
else
return false
end
end

L=is_even(0)
print(L)
