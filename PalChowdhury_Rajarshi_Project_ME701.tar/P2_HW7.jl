using PyCall
using PyPlot
@pyimport matplotlib.animation as anim
@pyimport matplotlib.pyplot as plt

alpha=0

function getTemp(alpha, L=1, tMax=0.1)
    dt = 0.00005
    dx = 0.01
    Nx = int(L / dx)
    dx = L / Nx
    Nt = int(tMax / dt)
    dt = tMax / Nt

    dx = L / Nx
    dt = tMax / Nt

    temp = zeros(Nx)
    temp[0] = 1

    for i=1:Nt
        temp[1:-1] += dt * alpha / dx ** 2 * (temp[0:-2] - 2 * temp[1:-1] + temp[2:])
    end
    return (temp, linspace(0, L, Nx))
     end
function animate(*args)
    global alpha
    alpha=alpha+0.01
    t,x=getTemp(alpha,L=1,tMax=0.1)
    T1=append(line.get_ydata(), t)
    X=append(line.get_xdata(), x)
    line.set_xdata(X)
    line.set_ydata(T1)
    fig.canvas.draw()
    return line,
     end

T1, x = getTemp(alpha,L=1,tMax=0.1)
fig = plt.figure()
ax = fig.add_subplot(111)
ax.set_aspect('equal')
line,=ax.plot(x,T1)


ani=anim.FuncAnimation(fig,animate, interval=100,blit=True)
plt.show()
ani[:save]("Julia_anim_HW7.mp4",extra_args=["-vcodec" ,"libx264","-pix_fmt","yuv420p"])
